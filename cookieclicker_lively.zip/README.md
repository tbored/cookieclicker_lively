# MADE BY TBORED

I DO NOT OWN COOKIE CLICKER

[My GitHub](https://github.com/tbored)